#!/usr/bin/env python3
"""
ShotBoard — a lightweight Movie Magic Scheduling alternative.
Import a PDF screenplay, auto-suggest cast, break down scenes, build a
stripboard, auto-suggest day breaks by location, and export printable reports.

Run:  python3 scheduler.py

Optional dependencies:
    pdfplumber  -> PDF script import          (pip install pdfplumber)
    reportlab   -> direct PDF report export    (pip install reportlab)
"""
from budget import BudgetWindow
import json
import re
import os
import datetime
import webbrowser
from collections import OrderedDict
from html import escape as html_escape

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

# Optional PDF *import* support
try:
    import pdfplumber
    HAS_PDF = True
except Exception:
    HAS_PDF = False

# Optional PDF *export* support
try:
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.lib.units import inch
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Preformatted
    HAS_PDF_EXPORT = True
except Exception:
    HAS_PDF_EXPORT = False


# ----------------------------- Data / constants -----------------------------

CATEGORIES = [
    "Cast", "Background", "Stunts", "Vehicles", "Props", "Camera",
    "Special Effects", "Wardrobe", "Makeup/Hair", "Animals", "Music",
    "Sound", "Set Dressing", "Greenery", "Special Equipment", "Security",
    "VFX", "Mechanical FX", "Notes", "Miscellaneous",
]

LINES_PER_PAGE = 55  # used to estimate page eighths from line counts

SCENE_HEADING_RE = re.compile(
    r'^\s*(?P<num>\d+[A-Za-z]?)?\s*'
    r'(?P<ie>INT\.?/EXT\.?|EXT\.?/INT\.?|I/E\.?|INT\.?|EXT\.?)'
    r'[\.\s\-:]+(?P<rest>.+?)\s*(?P<endnum>\d+[A-Za-z]?)?\s*$',
    re.IGNORECASE,
)

TIME_KEYWORDS = ["DAY", "NIGHT", "DAWN", "DUSK", "MORNING", "EVENING",
                 "AFTERNOON", "CONTINUOUS", "LATER", "MAGIC HOUR", "SUNSET", "SUNRISE"]

# Words that look like character cues but are not characters
NON_CHARACTER = {
    "LATER", "MOMENTS LATER", "CONTINUOUS", "THE END", "SUPER", "TITLE",
    "ANGLE", "ANGLE ON", "CLOSE", "CLOSE ON", "CLOSER", "INSERT", "POV",
    "P.O.V.", "MONTAGE", "SERIES OF SHOTS", "BEGIN", "END", "BACK",
    "BACK TO", "CONTINUED", "INTERCUT", "SMASH CUT", "CUT", "DISSOLVE",
    "FADE", "MATCH CUT", "WIDE", "WIDER", "TIGHT", "REVERSE", "FLASHBACK",
    "FLASH", "PRELAP", "BEAT", "PAUSE", "SILENCE", "DAY", "NIGHT", "DAWN",
    "DUSK", "MORNING", "EVENING", "AFTERNOON", "MEANWHILE", "SAME", "OMITTED",
}


def new_project():
    return {
        "title": "Untitled Production",
        "shoot_start": datetime.date.today().isoformat(),
        "scenes": [],   # list of scene dicts
        "board": [],    # ordered list: {"type":"scene","scene_id":id} or {"type":"break","label":...}
        "_next_id": 1,
    }


def normalize_ie(raw):
    r = raw.upper().replace(".", "")
    if "/" in r or r in ("IE",):
        return "I/E"
    if r.startswith("INT"):
        return "INT"
    if r.startswith("EXT"):
        return "EXT"
    return r


def parse_heading_rest(rest):
    """Split 'KITCHEN - DAY' into (location, time)."""
    rest = rest.strip().rstrip("-").strip()
    location, time = rest, ""
    if " - " in rest:
        parts = rest.rsplit(" - ", 1)
        location = parts[0].strip()
        tail = parts[1].strip().upper()
        if any(k in tail for k in TIME_KEYWORDS):
            time = parts[1].strip()
        else:
            location = rest
    else:
        up = rest.upper()
        for k in TIME_KEYWORDS:
            if up.endswith(k):
                location = rest[: -len(k)].rstrip(" -,").strip()
                time = rest[-len(k):].strip()
                break
    return location, time


def estimate_eighths(line_count):
    e = round((line_count / LINES_PER_PAGE) * 8)
    return max(1, min(e, 64))


def eighths_to_str(e):
    e = int(e)
    pages, rem = divmod(e, 8)
    if pages and rem:
        return f"{pages} {rem}/8"
    if pages:
        return f"{pages}"
    return f"{rem}/8"


def time_is_night(time_str):
    t = (time_str or "").upper()
    return any(k in t for k in ["NIGHT", "DUSK", "EVENING"])


# ----------------------------- Script parsing -----------------------------

def split_into_scenes(full_text):
    """Return list of scene dicts (without ids) from raw script text."""
    lines = full_text.splitlines()
    scenes = []
    current = None

    def flush(end_idx, start_idx):
        if current is not None:
            body = lines[start_idx:end_idx]
            current["raw_text"] = "\n".join(body).strip()
            current["pages_eighths"] = estimate_eighths(max(1, len([l for l in body if l.strip()])))
            scenes.append(current)

    last_start = 0
    for i, line in enumerate(lines):
        m = SCENE_HEADING_RE.match(line)
        if m and m.group("ie"):
            flush(i, last_start)
            location, time = parse_heading_rest(m.group("rest"))
            num = m.group("num") or m.group("endnum") or str(len(scenes) + 1)
            current = {
                "number": str(num),
                "int_ext": normalize_ie(m.group("ie")),
                "location": location.strip(" .-"),
                "time": time,
                "synopsis": "",
                "raw_text": "",
                "pages_eighths": 8,
                "elements": {c: [] for c in CATEGORIES},
            }
            last_start = i + 1
    flush(len(lines), last_start)
    return scenes


def extract_characters(raw_text):
    """Detect ALL-CAPS character cues in a scene body. Returns {name: count}."""
    counts = {}
    for raw in (raw_text or "").splitlines():
        s = raw.strip()
        if len(s) < 2:
            continue
        # strip trailing parenthetical extension e.g. (V.O.), (CONT'D)
        core = re.sub(r'\s*\([^)]*\)\s*$', '', s).strip().rstrip(':').strip()
        if len(core) < 2 or len(core) > 30:
            continue
        if core.endswith('.'):
            continue
        if not any(ch.isalpha() for ch in core):
            continue
        if core != core.upper():
            continue
        words = core.split()
        if len(words) > 4:
            continue
        if core in NON_CHARACTER:
            continue
        if words[0].rstrip('.') in ("INT", "EXT", "I/E"):
            continue
        if any(w in TIME_KEYWORDS for w in words):
            continue
        counts[core] = counts.get(core, 0) + 1
    return counts


def read_pdf_text(path):
    text_chunks = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            t = page.extract_text() or ""
            text_chunks.append(t)
    return "\n".join(text_chunks)


# ----------------------------- Scheduling helpers -----------------------------

def shoot_days(project):
    """Return list of days; each day is a list of scene dicts (in board order)."""
    scene_index = {s["id"]: s for s in project["scenes"]}
    segments = []
    cur = []
    for item in project["board"]:
        if item["type"] == "break":
            segments.append(cur)
            cur = []
        else:
            sc = scene_index.get(item["scene_id"])
            if sc:
                cur.append(sc)
    segments.append(cur)
    days = [seg for seg in segments if seg]
    return days if days else [[]]


def day_dates(project, n_days):
    try:
        start = datetime.date.fromisoformat(project["shoot_start"])
    except Exception:
        start = datetime.date.today()
    return [start + datetime.timedelta(days=i) for i in range(max(n_days, 1))]


# ----------------------------- Reusable checklist dialog -----------------------------

class CheckListDialog(tk.Toplevel):
    """Modal dialog with a scrollable list of checkbuttons. result -> set of keys or None."""

    def __init__(self, parent, title, prompt, items):
        super().__init__(parent)
        self.title(title)
        self.result = None
        self.transient(parent)
        self.grab_set()

        ttk.Label(self, text=prompt, wraplength=440).pack(padx=12, pady=10, anchor="w")

        container = ttk.Frame(self)
        container.pack(fill="both", expand=True, padx=12)
        canvas = tk.Canvas(container, height=360, highlightthickness=0)
        sb = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        self.vars = {}
        for key, label, default in items:
            v = tk.BooleanVar(value=default)
            self.vars[key] = v
            ttk.Checkbutton(inner, text=label, variable=v).pack(anchor="w", pady=1)

        btns = ttk.Frame(self)
        btns.pack(fill="x", pady=10, padx=12)
        ttk.Button(btns, text="Select All",
                   command=lambda: [v.set(True) for v in self.vars.values()]).pack(side="left")
        ttk.Button(btns, text="None",
                   command=lambda: [v.set(False) for v in self.vars.values()]).pack(side="left", padx=4)
        ttk.Button(btns, text="Cancel", command=self._cancel).pack(side="right")
        ttk.Button(btns, text="OK", command=self._ok).pack(side="right", padx=4)

        self.geometry("500x520")
        self.wait_window(self)

    def _ok(self):
        self.result = {k for k, v in self.vars.items() if v.get()}
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


# ----------------------------- Main Application -----------------------------

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ShotBoard — Script Breakdown & Scheduling")
        self.geometry("1180x740")
        self.project = new_project()
        self.filepath = None

        self._build_menu()
        self._build_ui()
        self.refresh_all()

    # ---------- Menu ----------
    def _build_menu(self):
        m = tk.Menu(self)
        filem = tk.Menu(m, tearoff=0)
        filem.add_command(label="New Project", command=self.new_project, accelerator="Cmd+N")
        filem.add_command(label="Open…", command=self.open_project, accelerator="Cmd+O")
        filem.add_command(label="Save", command=self.save_project, accelerator="Cmd+S")
        filem.add_command(label="Save As…", command=self.save_project_as)
        filem.add_separator()
        filem.add_command(label="Import PDF Script…", command=self.import_pdf)
        filem.add_command(label="Import Text Script…", command=self.import_text)
        filem.add_separator()
        filem.add_command(label="Quit", command=self.quit)
        m.add_cascade(label="File", menu=filem)

        toolsm = tk.Menu(m, tearoff=0)
        toolsm.add_command(label="Auto-Tag Cast (all scenes)…", command=self.suggest_cast_all)
        toolsm.add_command(label="Suggest Day Breaks…", command=self.suggest_day_breaks)
        toolsm.add_separator()
        toolsm.add_command(label="Open Budget…", command=self.open_budget)
        m.add_cascade(label="Tools", menu=toolsm)

        repm = tk.Menu(m, tearoff=0)
        repm.add_command(label="One-Line Schedule…", command=lambda: self.export_report("oneline"))
        repm.add_command(label="Breakdown Sheets…", command=lambda: self.export_report("breakdown"))
        repm.add_command(label="Cast List…", command=lambda: self.export_report("cast"))
        repm.add_command(label="Day Out of Days…", command=lambda: self.export_report("dood"))
        m.add_cascade(label="Reports", menu=repm)
        self.config(menu=m)

        self.bind_all("<Command-n>", lambda e: self.new_project())
        self.bind_all("<Command-o>", lambda e: self.open_project())
        self.bind_all("<Command-s>", lambda e: self.save_project())

    # ----------------------------- Budget integration -----------------------------
    def get_schedule_days(self):
        """
        Return {tag: day_count} for budget.py to drive linked line-item quantities.
        Tags offered:
            "Total Shoot Days"  – total number of shooting days on the board
            "Night Days"        – days containing at least one NIGHT scene
            "Loc: <LOCATION>"   – days that include at least one scene at that set
        """
        days = [d for d in shoot_days(self.project) if d]   # drop empty placeholder
        counts = {"Total Shoot Days": len(days)}

        loc_days = {}
        night_days = 0
        for day in days:
            is_night = False
            locations_today = set()
            for sc in day:
                loc = (sc["location"] or "").strip().upper() or "UNSPECIFIED"
                locations_today.add(loc)
                if time_is_night(sc["time"]):
                    is_night = True
            for loc in locations_today:
                loc_days[loc] = loc_days.get(loc, 0) + 1
            if is_night:
                night_days += 1

        counts["Night Days"] = night_days
        for loc, n in sorted(loc_days.items()):
            counts[f"Loc: {loc}"] = n   # "Loc:" prefix keeps locations grouped in the dropdown
        return counts

    def open_budget(self):
        # push the latest title into the project before launching
        self.project["title"] = self.title_var.get()
        BudgetWindow(
            self,
            project_name=self.project["title"],
            schedule_provider=self.get_schedule_days,
        )

    # ---------- UI layout ----------
    def _build_ui(self):
        top = ttk.Frame(self, padding=6)
        top.pack(fill="x")
        ttk.Label(top, text="Production:").pack(side="left")
        self.title_var = tk.StringVar(value=self.project["title"])
        e = ttk.Entry(top, textvariable=self.title_var, width=34)
        e.pack(side="left", padx=4)
        e.bind("<FocusOut>", lambda ev: self.project.update(title=self.title_var.get()))
        ttk.Label(top, text="Shoot start (YYYY-MM-DD):").pack(side="left", padx=(16, 2))
        self.start_var = tk.StringVar(value=self.project["shoot_start"])
        se = ttk.Entry(top, textvariable=self.start_var, width=12)
        se.pack(side="left")
        se.bind("<FocusOut>", lambda ev: (self.project.update(shoot_start=self.start_var.get()),
                                          self.refresh_board()))

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=6, pady=6)
        self._build_breakdown_tab()
        self._build_board_tab()
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.refresh_board())

    # ---------- Breakdown tab ----------
    def _build_breakdown_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="Breakdown")

        paned = ttk.PanedWindow(tab, orient="horizontal")
        paned.pack(fill="both", expand=True)

        # Left: scene list
        left = ttk.Frame(paned)
        paned.add(left, weight=1)
        cols = ("num", "ie", "set", "dn", "pages")
        self.scene_tree = ttk.Treeview(left, columns=cols, show="headings", height=20)
        for c, t, w in [("num", "Sc#", 45), ("ie", "I/E", 50), ("set", "Set", 180),
                        ("dn", "D/N", 60), ("pages", "Pgs", 50)]:
            self.scene_tree.heading(c, text=t)
            self.scene_tree.column(c, width=w, anchor="w")
        self.scene_tree.pack(fill="both", expand=True, side="left")
        sb = ttk.Scrollbar(left, orient="vertical", command=self.scene_tree.yview)
        sb.pack(side="right", fill="y")
        self.scene_tree.configure(yscrollcommand=sb.set)
        self.scene_tree.bind("<<TreeviewSelect>>", self.on_scene_select)

        btns = ttk.Frame(left)
        btns.pack(fill="x")
        ttk.Button(btns, text="Add Scene", command=self.add_scene).pack(side="left", padx=2, pady=4)
        ttk.Button(btns, text="Delete Scene", command=self.delete_scene).pack(side="left", padx=2)

        # Right: scene detail + elements
        right = ttk.Frame(paned, padding=8)
        paned.add(right, weight=2)

        grid = ttk.Frame(right)
        grid.pack(fill="x")
        self.fld = {}

        def field(row, label, key, width=30):
            ttk.Label(grid, text=label).grid(row=row, column=0, sticky="e", padx=4, pady=2)
            v = tk.StringVar()
            ent = ttk.Entry(grid, textvariable=v, width=width)
            ent.grid(row=row, column=1, sticky="w", padx=4, pady=2)
            self.fld[key] = v
            return v

        field(0, "Scene #", "number", 10)
        ttk.Label(grid, text="I/E").grid(row=0, column=2, sticky="e")
        self.fld["int_ext"] = tk.StringVar()
        ttk.Combobox(grid, textvariable=self.fld["int_ext"], values=["INT", "EXT", "I/E"],
                     width=6, state="readonly").grid(row=0, column=3, sticky="w", padx=4)
        field(1, "Set / Location", "location", 40)
        field(2, "Time of Day", "time", 20)
        field(3, "Page eighths (8 = 1 page)", "pages_eighths", 8)

        ttk.Label(grid, text="Synopsis").grid(row=4, column=0, sticky="ne", padx=4, pady=2)
        self.synopsis_txt = tk.Text(grid, width=50, height=3, wrap="word")
        self.synopsis_txt.grid(row=4, column=1, columnspan=3, sticky="w", padx=4, pady=2)

        ttk.Button(right, text="Update Scene", command=self.update_scene).pack(anchor="w", pady=6)

        # Elements
        elem_frame = ttk.LabelFrame(right, text="Breakdown Elements", padding=6)
        elem_frame.pack(fill="both", expand=True)

        addrow = ttk.Frame(elem_frame)
        addrow.pack(fill="x")
        self.cat_var = tk.StringVar(value=CATEGORIES[0])
        ttk.Combobox(addrow, textvariable=self.cat_var, values=CATEGORIES,
                     width=16, state="readonly").pack(side="left", padx=2)
        self.elem_var = tk.StringVar()
        ee = ttk.Entry(addrow, textvariable=self.elem_var, width=30)
        ee.pack(side="left", padx=2)
        ee.bind("<Return>", lambda e: self.add_element())
        ttk.Button(addrow, text="Tag Element", command=self.add_element).pack(side="left", padx=2)
        ttk.Button(addrow, text="Remove Selected", command=self.remove_element).pack(side="left", padx=2)

        sugrow = ttk.Frame(elem_frame)
        sugrow.pack(fill="x", pady=(4, 2))
        ttk.Button(sugrow, text="Suggest Cast (this scene)…",
                   command=self.suggest_cast_scene).pack(side="left", padx=2)
        ttk.Button(sugrow, text="Auto-Tag Cast (all scenes)…",
                   command=self.suggest_cast_all).pack(side="left", padx=2)

        self.elem_tree = ttk.Treeview(elem_frame, columns=("cat", "name"), show="headings", height=10)
        self.elem_tree.heading("cat", text="Category")
        self.elem_tree.heading("name", text="Element")
        self.elem_tree.column("cat", width=160)
        self.elem_tree.column("name", width=320)
        self.elem_tree.pack(fill="both", expand=True, pady=4)

        ttk.Label(elem_frame, text="Scene text (for reference):").pack(anchor="w")
        self.raw_txt = tk.Text(elem_frame, height=6, wrap="word", state="disabled",
                               background="#f4f4f4")
        self.raw_txt.pack(fill="both", expand=False)

    # ---------- Stripboard / schedule tab ----------
    def _build_board_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="Stripboard / Schedule")

        toolbar = ttk.Frame(tab)
        toolbar.pack(fill="x", pady=4)
        ttk.Button(toolbar, text="↑ Move Up", command=lambda: self.move_strip(-1)).pack(side="left", padx=2)
        ttk.Button(toolbar, text="↓ Move Down", command=lambda: self.move_strip(1)).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Insert Day Break", command=self.insert_break).pack(side="left", padx=8)
        ttk.Button(toolbar, text="Remove Break", command=self.remove_break).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Suggest Day Breaks…",
                   command=self.suggest_day_breaks).pack(side="left", padx=8)
        ttk.Button(toolbar, text="Rebuild from Scenes",
                   command=self.rebuild_board).pack(side="left", padx=16)
        ttk.Button(toolbar, text="Budget…",
                   command=self.open_budget).pack(side="left", padx=16)
        legend = ttk.Label(toolbar,
                           text="  Day-Int=white  Day-Ext=yellow  Night-Int=blue  Night-Ext=green")
        legend.pack(side="right")

        cols = ("info", "ie", "set", "dn", "pages", "cast")
        self.board_tree = ttk.Treeview(tab, columns=cols, show="headings", height=26)
        for c, t, w in [("info", "Day / Scene", 230), ("ie", "I/E", 55), ("set", "Set", 230),
                        ("dn", "D/N", 70), ("pages", "Pgs", 60), ("cast", "Cast", 300)]:
            self.board_tree.heading(c, text=t)
            self.board_tree.column(c, width=w, anchor="w")
        self.board_tree.pack(fill="both", expand=True, padx=4)

        self.board_tree.tag_configure("day_int", background="#ffffff")
        self.board_tree.tag_configure("day_ext", background="#fff7b0")
        self.board_tree.tag_configure("night_int", background="#bcd4ff")
        self.board_tree.tag_configure("night_ext", background="#bff0c0")
        self.board_tree.tag_configure("break", background="#333333", foreground="#ffffff")

    # ----------------------------- Scene helpers -----------------------------
    def scene_by_id(self, sid):
        for s in self.project["scenes"]:
            if s["id"] == sid:
                return s
        return None

    def selected_scene(self):
        sel = self.scene_tree.selection()
        if not sel:
            return None
        return self.scene_by_id(int(sel[0]))

    def refresh_all(self):
        self.title_var.set(self.project["title"])
        self.start_var.set(self.project["shoot_start"])
        self.refresh_scene_list()
        self.refresh_board()

    def refresh_scene_list(self):
        self.scene_tree.delete(*self.scene_tree.get_children())
        for s in self.project["scenes"]:
            dn = "N" if time_is_night(s["time"]) else "D"
            self.scene_tree.insert("", "end", iid=str(s["id"]),
                                   values=(s["number"], s["int_ext"], s["location"],
                                           dn, eighths_to_str(s["pages_eighths"])))

    def on_scene_select(self, _=None):
        s = self.selected_scene()
        if not s:
            return
        self.fld["number"].set(s["number"])
        self.fld["int_ext"].set(s["int_ext"])
        self.fld["location"].set(s["location"])
        self.fld["time"].set(s["time"])
        self.fld["pages_eighths"].set(str(s["pages_eighths"]))
        self.synopsis_txt.delete("1.0", "end")
        self.synopsis_txt.insert("1.0", s.get("synopsis", ""))
        self.raw_txt.configure(state="normal")
        self.raw_txt.delete("1.0", "end")
        self.raw_txt.insert("1.0", s.get("raw_text", ""))
        self.raw_txt.configure(state="disabled")
        self.refresh_elements(s)

    def refresh_elements(self, s):
        self.elem_tree.delete(*self.elem_tree.get_children())
        for cat in CATEGORIES:
            for name in s["elements"].get(cat, []):
                self.elem_tree.insert("", "end", values=(cat, name))

    def update_scene(self):
        s = self.selected_scene()
        if not s:
            messagebox.showinfo("No scene", "Select a scene first.")
            return
        s["number"] = self.fld["number"].get().strip()
        s["int_ext"] = self.fld["int_ext"].get().strip() or "INT"
        s["location"] = self.fld["location"].get().strip()
        s["time"] = self.fld["time"].get().strip()
        try:
            s["pages_eighths"] = max(1, int(float(self.fld["pages_eighths"].get())))
        except ValueError:
            s["pages_eighths"] = 8
        s["synopsis"] = self.synopsis_txt.get("1.0", "end").strip()
        self.refresh_scene_list()
        self.scene_tree.selection_set(str(s["id"]))
        self.refresh_board()

    def add_scene(self):
        sid = self.project["_next_id"]
        self.project["_next_id"] += 1
        s = {"id": sid, "number": str(len(self.project["scenes"]) + 1), "int_ext": "INT",
             "location": "NEW LOCATION", "time": "DAY", "synopsis": "", "raw_text": "",
             "pages_eighths": 8, "elements": {c: [] for c in CATEGORIES}}
        self.project["scenes"].append(s)
        self.project["board"].append({"type": "scene", "scene_id": sid})
        self.refresh_scene_list()
        self.scene_tree.selection_set(str(sid))

    def delete_scene(self):
        s = self.selected_scene()
        if not s:
            return
        if not messagebox.askyesno("Delete", f"Delete scene {s['number']} — {s['location']}?"):
            return
        self.project["scenes"] = [x for x in self.project["scenes"] if x["id"] != s["id"]]
        self.project["board"] = [b for b in self.project["board"]
                                 if not (b["type"] == "scene" and b["scene_id"] == s["id"])]
        self.refresh_scene_list()
        self.refresh_board()

    def add_element(self):
        s = self.selected_scene()
        if not s:
            messagebox.showinfo("No scene", "Select a scene first.")
            return
        name = self.elem_var.get().strip()
        if not name:
            return
        cat = self.cat_var.get()
        if name not in s["elements"][cat]:
            s["elements"][cat].append(name)
        self.elem_var.set("")
        self.refresh_elements(s)
        self.refresh_board()

    def remove_element(self):
        s = self.selected_scene()
        sel = self.elem_tree.selection()
        if not s or not sel:
            return
        for iid in sel:
            cat, name = self.elem_tree.item(iid, "values")
            if name in s["elements"].get(cat, []):
                s["elements"][cat].remove(name)
        self.refresh_elements(s)
        self.refresh_board()

    # ----------------------------- Cast auto-suggestion -----------------------------
    def suggest_cast_scene(self):
        s = self.selected_scene()
        if not s:
            messagebox.showinfo("No scene", "Select a scene first.")
            return
        cands = extract_characters(s.get("raw_text", ""))
        # don't re-offer already-tagged names
        cands = {n: c for n, c in cands.items() if n not in s["elements"]["Cast"]}
        if not cands:
            messagebox.showinfo("Suggest Cast",
                                "No new character cues detected in this scene.")
            return
        items = [(n, f"{n}   ({c}× cue{'s' if c > 1 else ''})", True)
                 for n, c in sorted(cands.items(), key=lambda x: (-x[1], x[0]))]
        dlg = CheckListDialog(self, "Suggested Cast",
                              "Select detected names to tag as Cast for this scene:", items)
        if dlg.result:
            for n in dlg.result:
                if n not in s["elements"]["Cast"]:
                    s["elements"]["Cast"].append(n)
            self.refresh_elements(s)
            self.refresh_board()

    def suggest_cast_all(self):
        scenes = self.project["scenes"]
        if not scenes:
            messagebox.showinfo("Auto-Tag Cast", "Import or add some scenes first.")
            return
        per = {}
        glob = {}
        for s in scenes:
            c = extract_characters(s.get("raw_text", ""))
            per[s["id"]] = c
            for n, cnt in c.items():
                glob[n] = glob.get(n, 0) + cnt
        if not glob:
            messagebox.showinfo("Auto-Tag Cast",
                                "No character cues detected. (Scanned/image PDFs won't work.)")
            return
        nscenes = {n: sum(1 for c in per.values() if n in c) for n in glob}
        items = [(n, f"{n}   —   {glob[n]}× cues in {nscenes[n]} scene(s)", True)
                 for n in sorted(glob, key=lambda x: (-glob[x], x))]
        dlg = CheckListDialog(
            self, "Auto-Tag Cast (all scenes)",
            "Approved names will be tagged as Cast in every scene where they appear. "
            "Un-check anything that's a sound effect or false positive:", items)
        if dlg.result is None:
            return
        approved = dlg.result
        added = 0
        for s in scenes:
            for n in per[s["id"]]:
                if n in approved and n not in s["elements"]["Cast"]:
                    s["elements"]["Cast"].append(n)
                    added += 1
        cur = self.selected_scene()
        if cur:
            self.refresh_elements(cur)
        self.refresh_board()
        messagebox.showinfo("Auto-Tag Cast",
                            f"Tagged {added} cast entries across {len(scenes)} scenes.")

    # ----------------------------- Stripboard -----------------------------
    def rebuild_board(self):
        if self.project["board"] and not messagebox.askyesno(
                "Rebuild", "Rebuild the board from scene order? Day breaks will be cleared."):
            return
        self.project["board"] = [{"type": "scene", "scene_id": s["id"]}
                                 for s in self.project["scenes"]]
        self.refresh_board()

    def refresh_board(self):
        if not hasattr(self, "board_tree"):
            return
        self.board_tree.delete(*self.board_tree.get_children())
        board = self.project["board"]
        scene_index = {s["id"]: s for s in self.project["scenes"]}

        # Determine where each shoot-day starts: (scene_board_index, break_board_index_or_None)
        day_starts = []
        last_break = None
        in_day = False
        for idx, item in enumerate(board):
            if item["type"] == "break":
                last_break = idx
                in_day = False
            else:
                if scene_index.get(item["scene_id"]) is None:
                    continue
                if not in_day:
                    day_starts.append((idx, last_break))
                    in_day = True
                    last_break = None

        days = shoot_days(self.project)
        dates = day_dates(self.project, len(days))
        day_of_scene = {sc_idx: k for k, (sc_idx, _) in enumerate(day_starts)}
        break_of_day = {k: brk for k, (_, brk) in enumerate(day_starts)}

        for idx, item in enumerate(board):
            if item["type"] == "break":
                continue
            sc = scene_index.get(item["scene_id"])
            if sc is None:
                continue

            if idx in day_of_scene:
                k = day_of_scene[idx]
                date = dates[k] if k < len(dates) else None
                total = sum(x["pages_eighths"] for x in days[k]) if k < len(days) else 0
                brk = break_of_day[k]
                custom = board[brk].get("label", "") if brk is not None else ""
                base = f"DAY {k + 1}"
                if custom and not custom.upper().startswith("DAY"):
                    base += f" — {custom}"
                date_str = date.strftime("%a %b %d, %Y") if date else ""
                header = f"— {base} —   {date_str}   ({eighths_to_str(total)} pgs)"
                header_iid = f"i{brk}" if brk is not None else f"h{idx}"
                self.board_tree.insert("", "end", iid=header_iid,
                                       values=(header, "", "", "", "", ""), tags=("break",))

            night = time_is_night(sc["time"])
            ext = sc["int_ext"] in ("EXT", "I/E")
            if night and ext:
                tag = "night_ext"
            elif night:
                tag = "night_int"
            elif ext:
                tag = "day_ext"
            else:
                tag = "day_int"
            cast = ", ".join(sc["elements"].get("Cast", []))
            dn = "NIGHT" if night else "DAY"
            self.board_tree.insert("", "end", iid=f"i{idx}",
                                   values=(f"Sc {sc['number']}", sc["int_ext"], sc["location"],
                                           dn, eighths_to_str(sc["pages_eighths"]), cast),
                                   tags=(tag,))

    def selected_board_index(self):
        sel = self.board_tree.selection()
        if not sel:
            return None
        iid = sel[0]
        if not iid.startswith("i"):
            return None
        try:
            return int(iid[1:])
        except ValueError:
            return None

    def move_strip(self, direction):
        idx = self.selected_board_index()
        if idx is None:
            return
        j = idx + direction
        if j < 0 or j >= len(self.project["board"]):
            return
        b = self.project["board"]
        b[idx], b[j] = b[j], b[idx]
        self.refresh_board()
        if self.board_tree.exists(f"i{j}"):
            self.board_tree.selection_set(f"i{j}")
            self.board_tree.see(f"i{j}")

    def insert_break(self):
        idx = self.selected_board_index()
        label = simpledialog.askstring("Day Break", "Label (leave blank for auto):", parent=self)
        item = {"type": "break", "label": label or ""}
        pos = idx if idx is not None else len(self.project["board"])
        self.project["board"].insert(pos, item)
        self.refresh_board()

    def remove_break(self):
        idx = self.selected_board_index()
        if idx is None:
            messagebox.showinfo("Remove Break", "Select a day-header row to remove its break.")
            return
        if self.project["board"][idx]["type"] != "break":
            messagebox.showinfo("Remove Break", "That row isn't a day break.")
            return
        del self.project["board"][idx]
        self.refresh_board()

    def suggest_day_breaks(self):
        if not self.project["scenes"]:
            messagebox.showinfo("Suggest Day Breaks", "Import or add some scenes first.")
            return
        target = simpledialog.askfloat(
            "Suggest Day Breaks",
            "Target pages per shooting day:",
            parent=self, initialvalue=5.0, minvalue=0.5, maxvalue=30.0)
        if target is None:
            return
        group_loc = messagebox.askyesno(
            "Group by Location",
            "Keep scenes that share a location together?\n\n"
            "Yes = company-move friendly (group by set)\n"
            "No  = preserve script order")
        if self.project["board"] and not messagebox.askyesno(
                "Confirm", "This will reorder the board and replace all day breaks. Continue?"):
            return

        target_e = max(1, int(round(target * 8)))
        scenes = self.project["scenes"]

        if group_loc:
            buckets = OrderedDict()
            for s in scenes:
                buckets.setdefault(s["location"].upper(), []).append(s)
            group_list = list(buckets.values())
        else:
            group_list = [[s] for s in scenes]

        days = []
        current = []
        current_e = 0
        for grp in group_list:
            grp_e = sum(s["pages_eighths"] for s in grp)
            if current and current_e + grp_e > target_e:
                days.append(current)
                current, current_e = [], 0
            current.extend(grp)
            current_e += grp_e
        if current:
            days.append(current)

        board = []
        for i, day in enumerate(days):
            if i > 0:
                board.append({"type": "break", "label": ""})
            for s in day:
                board.append({"type": "scene", "scene_id": s["id"]})
        self.project["board"] = board
        self.refresh_board()
        try:
            self.nb.select(1)
        except Exception:
            pass
        messagebox.showinfo("Suggest Day Breaks",
                            f"Built {len(days)} shooting days "
                            f"({'grouped by location' if group_loc else 'in script order'}, "
                            f"~{target:g} pgs/day target).")

    # ----------------------------- Import -----------------------------
    def import_pdf(self):
        if not HAS_PDF:
            messagebox.showerror("pdfplumber missing",
                                 "pdfplumber is not installed.\n\nRun in Terminal:\n"
                                 "python3 -m pip install pdfplumber")
            return
        path = filedialog.askopenfilename(filetypes=[("PDF", "*.pdf")])
        if not path:
            return
        try:
            text = read_pdf_text(path)
        except Exception as e:
            messagebox.showerror("Read error", str(e))
            return
        self._ingest_text(text, os.path.basename(path))

    def import_text(self):
        path = filedialog.askopenfilename(
            filetypes=[("Text/Fountain", "*.txt *.fountain"), ("All files", "*.*")])
        if not path:
            return
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        self._ingest_text(text, os.path.basename(path))

    def _ingest_text(self, text, name):
        scenes = split_into_scenes(text)
        if not scenes:
            messagebox.showwarning("No scenes",
                                   "No scene headings (INT./EXT.) were detected. "
                                   "The PDF may be scanned/image-based or non-standard.")
            return
        if self.project["scenes"] and not messagebox.askyesno(
                "Replace", "Replace the current project with the imported script?"):
            return
        self.project = new_project()
        self.project["title"] = os.path.splitext(name)[0]
        for sc in scenes:
            sid = self.project["_next_id"]
            self.project["_next_id"] += 1
            sc["id"] = sid
            self.project["scenes"].append(sc)
            self.project["board"].append({"type": "scene", "scene_id": sid})
        self.refresh_all()
        if messagebox.askyesno(
                "Imported",
                f"Imported {len(scenes)} scenes from {name}.\n\n"
                "Auto-detect cast from ALL-CAPS character cues now?"):
            self.suggest_cast_all()

    # ----------------------------- Save / Open -----------------------------
    def new_project(self):
        if messagebox.askyesno("New", "Start a new empty project?"):
            self.project = new_project()
            self.filepath = None
            self.refresh_all()

    def save_project(self):
        if not self.filepath:
            return self.save_project_as()
        self._write(self.filepath)

    def save_project_as(self):
        path = filedialog.asksaveasfilename(defaultextension=".sbproj",
                                            filetypes=[("ShotBoard Project", "*.sbproj")])
        if not path:
            return
        self.filepath = path
        self._write(path)

    def _write(self, path):
        self.project["title"] = self.title_var.get()
        self.project["shoot_start"] = self.start_var.get()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.project, f, indent=2)
        messagebox.showinfo("Saved", f"Saved to {path}")

    def open_project(self):
        path = filedialog.askopenfilename(filetypes=[("ShotBoard Project", "*.sbproj"),
                                                     ("JSON", "*.json")])
        if not path:
            return
        with open(path, "r", encoding="utf-8") as f:
            self.project = json.load(f)
        for s in self.project["scenes"]:
            for c in CATEGORIES:
                s["elements"].setdefault(c, [])
        self.filepath = path
        self.refresh_all()

    # ----------------------------- Reports -----------------------------
    def export_report(self, kind):
        if not self.project["scenes"]:
            messagebox.showinfo("Empty", "Nothing to report yet.")
            return
        titles = {"oneline": "One-Line Schedule", "breakdown": "Breakdown Sheets",
                  "cast": "Cast List", "dood": "Day Out of Days"}
        gen = {"oneline": self._report_oneline, "breakdown": self._report_breakdown,
               "cast": self._report_cast, "dood": self._report_dood}[kind]
        title = f"{titles[kind]} — {self.project['title']}"
        text = gen()
        landscape_mode = (kind == "dood")

        path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF", "*.pdf"), ("Printable HTML", "*.html"), ("Text", "*.txt")])
        if not path:
            return
        ext = os.path.splitext(path)[1].lower()

        if ext == ".pdf":
            if HAS_PDF_EXPORT:
                self._write_pdf(title, text, path, landscape_mode)
                messagebox.showinfo("Exported", f"PDF written to {path}")
            else:
                if messagebox.askyesno(
                        "reportlab not installed",
                        "Direct PDF export needs reportlab:\n"
                        "    python3 -m pip install reportlab\n\n"
                        "Export a printable HTML instead? You can open it and use\n"
                        "Print → Save as PDF (landscape is preset for DOOD)."):
                    hpath = os.path.splitext(path)[0] + ".html"
                    self._write_html(title, text, hpath, landscape_mode)
                    self._offer_open(hpath)
        elif ext == ".html":
            self._write_html(title, text, path, landscape_mode)
            self._offer_open(path)
        else:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
            messagebox.showinfo("Exported", f"Report written to {path}")

    def _offer_open(self, path):
        if messagebox.askyesno("Exported",
                               f"Saved to {path}\n\nOpen it in your browser now? "
                               "(Then Print → Save as PDF)"):
            webbrowser.open("file://" + os.path.abspath(path))

    def _write_pdf(self, title, text, path, landscape_mode):
        page = landscape(letter) if landscape_mode else letter
        doc = SimpleDocTemplate(path, pagesize=page, title=title,
                                leftMargin=0.5 * inch, rightMargin=0.5 * inch,
                                topMargin=0.5 * inch, bottomMargin=0.5 * inch)
        style = ParagraphStyle("mono", fontName="Courier",
                               fontSize=8, leading=10)
        doc.build([Preformatted(text, style)])

    def _write_html(self, title, text, path, landscape_mode):
        orient = "landscape" if landscape_mode else "portrait"
        html = (
            "<!DOCTYPE html><html><head><meta charset='utf-8'>"
            f"<title>{html_escape(title)}</title><style>"
            "body{font-family:Arial,Helvetica,sans-serif;margin:24px;}"
            "h1{font-size:16px;}"
            "pre{font-family:'Courier New',monospace;font-size:11px;white-space:pre-wrap;}"
            f"@media print{{@page{{size:{orient};margin:0.5in;}}}}"
            "</style></head><body>"
            f"<h1>{html_escape(title)}</h1>"
            f"<pre>{html_escape(text)}</pre></body></html>"
        )
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

    def _report_oneline(self):
        days = shoot_days(self.project)
        dates = day_dates(self.project, len(days))
        out = [f"ONE-LINE SCHEDULE — {self.project['title']}", "=" * 70, ""]
        for i, day in enumerate(days):
            total = sum(s["pages_eighths"] for s in day)
            out.append(f"DAY {i + 1} — {dates[i].strftime('%a %b %d, %Y')} "
                       f"({eighths_to_str(total)} pgs)")
            out.append("-" * 70)
            for s in day:
                dn = "NIGHT" if time_is_night(s["time"]) else "DAY"
                cast = ", ".join(s["elements"].get("Cast", []))
                out.append(f"  Sc {s['number']:<4} {s['int_ext']:<4} {s['location']:<28} "
                           f"{dn:<6} {eighths_to_str(s['pages_eighths']):>5}  | {cast}")
            out.append("")
        return "\n".join(out)

    def _report_breakdown(self):
        out = [f"BREAKDOWN SHEETS — {self.project['title']}", "=" * 70, ""]
        for s in self.project["scenes"]:
            out.append(f"Scene {s['number']}: {s['int_ext']}. {s['location']} - {s['time']}  "
                       f"({eighths_to_str(s['pages_eighths'])} pgs)")
            if s.get("synopsis"):
                out.append(f"  Synopsis: {s['synopsis']}")
            for cat in CATEGORIES:
                items = s["elements"].get(cat, [])
                if items:
                    out.append(f"  {cat}: {', '.join(items)}")
            out.append("-" * 70)
        return "\n".join(out)

    def _report_cast(self):
        cast = {}
        for s in self.project["scenes"]:
            for name in s["elements"].get("Cast", []):
                cast.setdefault(name, []).append(s["number"])
        out = [f"CAST LIST — {self.project['title']}", "=" * 70, ""]
        for name in sorted(cast):
            out.append(f"{name:<28} scenes: {', '.join(cast[name])}")
        return "\n".join(out)

    def _report_dood(self):
        days = shoot_days(self.project)
        cast = set()
        for s in self.project["scenes"]:
            cast.update(s["elements"].get("Cast", []))
        cast = sorted(cast)
        work = {c: [False] * len(days) for c in cast}
        for di, day in enumerate(days):
            day_cast = set()
            for s in day:
                day_cast.update(s["elements"].get("Cast", []))
            for c in day_cast:
                work[c][di] = True
        out = [f"DAY OUT OF DAYS — {self.project['title']}",
               "S=Start  W=Work  H=Hold  F=Finish  SF=Start/Finish", "=" * 70, ""]
        header = "Cast".ljust(24) + "".join(f"D{i + 1:<3}" for i in range(len(days)))
        out.append(header)
        out.append("-" * len(header))
        for c in cast:
            days_worked = [i for i, w in enumerate(work[c]) if w]
            if not days_worked:
                continue
            first, last = days_worked[0], days_worked[-1]
            row = c.ljust(24)
            for i in range(len(days)):
                if i == first == last:
                    code = "SF"
                elif i == first:
                    code = "S"
                elif i == last:
                    code = "F"
                elif work[c][i]:
                    code = "W"
                elif first < i < last:
                    code = "H"
                else:
                    code = ""
                row += code.ljust(4)
            out.append(row)
        return "\n".join(out)


if __name__ == "__main__":
    app = App()
    app.mainloop()
