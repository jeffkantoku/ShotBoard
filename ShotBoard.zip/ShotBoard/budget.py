import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from dataclasses import dataclass, field
from datetime import datetime
import json

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False


@dataclass
class LineItem:
    account: str
    description: str
    qty: float = 1.0
    units: str = "Flat"          # Days, Weeks, Hours, Flat
    rate: float = 0.0
    schedule_tag: str = ""       # if set, qty is driven by the schedule

    @property
    def linked(self) -> bool:
        return bool(self.schedule_tag)

    @property
    def total(self) -> float:
        return round(self.qty * self.rate, 2)

    def to_dict(self):
        return {
            "account": self.account, "description": self.description,
            "qty": self.qty, "units": self.units, "rate": self.rate,
            "schedule_tag": self.schedule_tag,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(
            account=d.get("account", ""),
            description=d.get("description", ""),
            qty=float(d.get("qty", 1.0)),
            units=d.get("units", "Flat"),
            rate=float(d.get("rate", 0.0)),
            schedule_tag=d.get("schedule_tag", ""),
        )


@dataclass
class Category:
    name: str
    items: list = field(default_factory=list)

    @property
    def subtotal(self) -> float:
        return round(sum(i.total for i in self.items), 2)

    def to_dict(self):
        return {"name": self.name, "items": [i.to_dict() for i in self.items]}

    @classmethod
    def from_dict(cls, d):
        cat = cls(d.get("name", "Unnamed"))
        cat.items = [LineItem.from_dict(x) for x in d.get("items", [])]
        return cat


class FilmBudget:
    """Holds the four standard sections and computes totals."""

    SECTIONS = [
        "Above-the-Line",
        "Below-the-Line: Production",
        "Below-the-Line: Post-Production",
        "Other (Insurance, Legal, etc.)",
    ]

    def __init__(self, project_name="Untitled Project"):
        self.project_name = project_name
        self.fringe_pct = 0.0
        self.contingency_pct = 10.0
        self.sections = {s: [] for s in self.SECTIONS}
        self._seed_defaults()

    def _seed_defaults(self):
        defaults = {
            "Above-the-Line": {
                "Story & Rights": [("1100", "Screenplay rights", 1, "Flat", 0)],
                "Producers": [("1200", "Producer fee", 1, "Flat", 0)],
                "Director": [("1300", "Director fee", 1, "Flat", 0)],
                "Cast": [("1400", "Lead actor", 1, "Weeks", 0)],
            },
            "Below-the-Line: Production": {
                "Production Staff": [("2000", "1st AD", 1, "Weeks", 0)],
                "Camera": [("2100", "DP", 1, "Weeks", 0),
                           ("2110", "Camera package rental", 1, "Days", 0)],
                "Grip & Electric": [("2200", "Gaffer", 1, "Weeks", 0),
                                    ("2210", "Lighting package", 1, "Days", 0)],
                "Art Department": [("2300", "Production designer", 1, "Weeks", 0)],
                "Locations": [("2400", "Location fees", 1, "Days", 0)],
            },
            "Below-the-Line: Post-Production": {
                "Editorial": [("3000", "Editor", 1, "Weeks", 0)],
                "Sound": [("3100", "Sound mix", 1, "Flat", 0)],
                "Music": [("3200", "Composer", 1, "Flat", 0)],
                "VFX & Color": [("3300", "Color grade", 1, "Flat", 0)],
            },
            "Other (Insurance, Legal, etc.)": {
                "Insurance": [("4000", "Production insurance", 1, "Flat", 0)],
                "Legal & Accounting": [("4100", "Legal", 1, "Flat", 0)],
            },
        }
        for section, cats in defaults.items():
            for cat_name, items in cats.items():
                cat = Category(cat_name)
                for acct, desc, qty, units, rate in items:
                    cat.items.append(LineItem(acct, desc, qty, units, rate))
                self.sections[section].append(cat)

    def section_total(self, section):
        return round(sum(c.subtotal for c in self.sections[section]), 2)

    @property
    def direct_total(self):
        return round(sum(self.section_total(s) for s in self.SECTIONS), 2)

    @property
    def fringe_amount(self):
        return round(self.direct_total * self.fringe_pct / 100.0, 2)

    @property
    def subtotal_with_fringes(self):
        return round(self.direct_total + self.fringe_amount, 2)

    @property
    def contingency_amount(self):
        return round(self.subtotal_with_fringes * self.contingency_pct / 100.0, 2)

    @property
    def grand_total(self):
        return round(self.subtotal_with_fringes + self.contingency_amount, 2)

    # ---------- Persistence ----------
    def to_dict(self):
        return {
            "format": "film-budget",
            "version": 1,
            "project_name": self.project_name,
            "fringe_pct": self.fringe_pct,
            "contingency_pct": self.contingency_pct,
            "sections": {
                s: [c.to_dict() for c in self.sections[s]]
                for s in self.SECTIONS
            },
        }

    def save_json(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def from_dict(cls, d):
        b = cls(d.get("project_name", "Untitled Project"))
        b.fringe_pct = float(d.get("fringe_pct", 0.0))
        b.contingency_pct = float(d.get("contingency_pct", 10.0))
        b.sections = {s: [] for s in cls.SECTIONS}
        for section, cats in d.get("sections", {}).items():
            if section not in b.sections:
                b.sections[section] = []
            b.sections[section] = [Category.from_dict(c) for c in cats]
        return b

    @classmethod
    def load_json(cls, path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("format") != "film-budget":
            raise ValueError("This file is not a film-budget JSON document.")
        return cls.from_dict(data)

    # ---------- Schedule sync ----------
    def apply_schedule(self, day_map):
        """day_map: {tag: day_count}. Updates qty of every linked item."""
        if not day_map:
            return 0
        updated = 0
        for section in self.SECTIONS:
            for cat in self.sections[section]:
                for item in cat.items:
                    if item.schedule_tag and item.schedule_tag in day_map:
                        item.qty = float(day_map[item.schedule_tag])
                        updated += 1
        return updated


class BudgetWindow(tk.Toplevel):
    """
    Budgeting window.

    schedule_provider: optional callable returning {tag: day_count}.
        Example: lambda: {"Total": 24, "INT. Warehouse": 6}
    """

    def __init__(self, master=None, project_name="Untitled Project",
                 schedule_provider=None):
        super().__init__(master)
        self.title("Film Budget")
        self.geometry("1040x680")
        self.schedule_provider = schedule_provider
        self.budget = FilmBudget(project_name)
        self.current_path = None
        self._build_ui()
        self._reload_tree()

    # ---------- UI construction ----------
    def _build_ui(self):
        top = ttk.Frame(self, padding=8)
        top.pack(fill="x")

        ttk.Label(top, text="Project:").pack(side="left")
        self.proj_var = tk.StringVar(value=self.budget.project_name)
        ttk.Entry(top, textvariable=self.proj_var, width=26).pack(side="left", padx=(4, 16))

        ttk.Label(top, text="Fringe %:").pack(side="left")
        self.fringe_var = tk.StringVar(value=str(self.budget.fringe_pct))
        ttk.Entry(top, textvariable=self.fringe_var, width=6).pack(side="left", padx=(4, 12))

        ttk.Label(top, text="Contingency %:").pack(side="left")
        self.cont_var = tk.StringVar(value=str(self.budget.contingency_pct))
        ttk.Entry(top, textvariable=self.cont_var, width=6).pack(side="left", padx=(4, 12))

        ttk.Button(top, text="Recalculate", command=self._recalc).pack(side="left")
        ttk.Button(top, text="Sync from Schedule",
                   command=self._sync_schedule).pack(side="left", padx=(12, 0))

        # File row
        filebar = ttk.Frame(self, padding=(8, 0))
        filebar.pack(fill="x")
        ttk.Button(filebar, text="New", command=self._new).pack(side="left")
        ttk.Button(filebar, text="Open…", command=self._open).pack(side="left", padx=4)
        ttk.Button(filebar, text="Save", command=self._save).pack(side="left")
        ttk.Button(filebar, text="Save As…", command=self._save_as).pack(side="left", padx=4)
        self.path_label = ttk.Label(filebar, text="(unsaved)", foreground="#666")
        self.path_label.pack(side="left", padx=10)

        # Treeview
        mid = ttk.Frame(self, padding=(8, 4))
        mid.pack(fill="both", expand=True)

        cols = ("account", "description", "qty", "units", "rate", "link", "total")
        self.tree = ttk.Treeview(mid, columns=cols, show="tree headings", height=20)
        headings = {
            "#0": "Section / Category", "account": "Acct",
            "description": "Description", "qty": "Qty", "units": "Units",
            "rate": "Rate", "link": "Linked To", "total": "Total",
        }
        for c, txt in headings.items():
            self.tree.heading(c, text=txt)
        self.tree.column("#0", width=250, anchor="w")
        self.tree.column("account", width=55, anchor="center")
        self.tree.column("description", width=210, anchor="w")
        self.tree.column("qty", width=55, anchor="e")
        self.tree.column("units", width=60, anchor="center")
        self.tree.column("rate", width=85, anchor="e")
        self.tree.column("link", width=120, anchor="w")
        self.tree.column("total", width=105, anchor="e")

        vsb = ttk.Scrollbar(mid, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.tree.tag_configure("section", background="#1f3a5f", foreground="white")
        self.tree.tag_configure("category", background="#dce6f2")
        self.tree.bind("<Double-1>", self._edit_item)

        # Bottom controls
        bottom = ttk.Frame(self, padding=8)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Add Line Item", command=self._add_item).pack(side="left")
        ttk.Button(bottom, text="Add Category", command=self._add_category).pack(side="left", padx=4)
        ttk.Button(bottom, text="Delete Selected", command=self._delete_selected).pack(side="left", padx=4)
        self.total_label = ttk.Label(bottom, text="", font=("Helvetica", 11, "bold"))
        self.total_label.pack(side="left", padx=14)
        ttk.Button(bottom, text="Export to Excel", command=self._export).pack(side="right")

    # ---------- Data <-> tree ----------
    def _reload_tree(self):
        self.tree.delete(*self.tree.get_children())
        for section in self.budget.SECTIONS:
            sec_id = self.tree.insert(
                "", "end", text=section, tags=("section",),
                values=("", "", "", "", "", "", self._fmt(self.budget.section_total(section))),
                open=True,
            )
            for ci, cat in enumerate(self.budget.sections[section]):
                cat_id = self.tree.insert(
                    sec_id, "end", text=cat.name, tags=("category",),
                    values=("", "", "", "", "", "", self._fmt(cat.subtotal)), open=True,
                )
                for ii, item in enumerate(cat.items):
                    link_txt = f"🔗 {item.schedule_tag}" if item.linked else ""
                    self.tree.insert(
                        cat_id, "end", text="",
                        values=(item.account, item.description, item.qty,
                                item.units, self._fmt(item.rate), link_txt,
                                self._fmt(item.total)),
                        tags=(f"item::{section}::{ci}::{ii}",),
                    )
        self._update_total_label()

    def _update_total_label(self):
        b = self.budget
        self.total_label.config(
            text=(f"Direct: {self._fmt(b.direct_total)}   "
                  f"+Fringe: {self._fmt(b.fringe_amount)}   "
                  f"+Cont.: {self._fmt(b.contingency_amount)}   "
                  f"= GRAND TOTAL: {self._fmt(b.grand_total)}")
        )

    @staticmethod
    def _fmt(v):
        try:
            return f"${v:,.2f}"
        except (TypeError, ValueError):
            return v

    # ---------- Schedule ----------
    def _get_day_map(self):
        if not self.schedule_provider:
            return {}
        try:
            data = self.schedule_provider() or {}
            return {str(k): float(v) for k, v in data.items()}
        except Exception as e:
            messagebox.showerror("Schedule error",
                                 f"Could not read schedule data:\n{e}")
            return {}

    def _sync_schedule(self):
        day_map = self._get_day_map()
        if not day_map:
            messagebox.showinfo(
                "No schedule",
                "No schedule data is available.\n\n"
                "Launch the budget from your scheduler and pass a "
                "schedule_provider to enable day-count linking.")
            return
        n = self.budget.apply_schedule(day_map)
        self._reload_tree()
        messagebox.showinfo("Synced",
                            f"Updated {n} linked line item(s) from the schedule.")

    # ---------- Actions ----------
    def _recalc(self):
        self.budget.project_name = self.proj_var.get()
        try:
            self.budget.fringe_pct = float(self.fringe_var.get())
            self.budget.contingency_pct = float(self.cont_var.get())
        except ValueError:
            messagebox.showerror("Invalid input", "Fringe and contingency must be numbers.")
            return
        self._reload_tree()

    def _selected_section(self):
        sel = self.tree.selection()
        if not sel:
            return None, None
        node = sel[0]
        while self.tree.parent(node):
            node = self.tree.parent(node)
        return self.tree.item(node, "text"), sel[0]

    def _add_category(self):
        section, _ = self._selected_section()
        if not section:
            messagebox.showinfo("Select a section", "Click a section first.")
            return
        name = self._prompt("New category name:")
        if name:
            self.budget.sections[section].append(Category(name))
            self._reload_tree()

    def _add_item(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Select a category", "Click a category to add an item to.")
            return
        section, _ = self._selected_section()
        node = sel[0]
        cat_node = node
        if self.tree.parent(node) and self.tree.parent(self.tree.parent(node)):
            cat_node = self.tree.parent(node)
        cat_name = self.tree.item(cat_node, "text")
        for cat in self.budget.sections.get(section, []):
            if cat.name == cat_name:
                cat.items.append(LineItem("", "New item", 1, "Flat", 0.0))
                self._reload_tree()
                return
        messagebox.showinfo("Select a category", "Please select a category row.")

    def _delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        tags = self.tree.item(sel[0], "tags")
        for t in tags:
            if t.startswith("item::"):
                _, section, ci, ii = t.split("::")
                del self.budget.sections[section][int(ci)].items[int(ii)]
                self._reload_tree()
                return
        section, _ = self._selected_section()
        cat_name = self.tree.item(sel[0], "text")
        cats = self.budget.sections.get(section, [])
        for i, c in enumerate(cats):
            if c.name == cat_name and self.tree.parent(sel[0]):
                if messagebox.askyesno("Delete category",
                                       f"Delete '{cat_name}' and all its items?"):
                    del cats[i]
                    self._reload_tree()
                return

    def _edit_item(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        tags = self.tree.item(sel[0], "tags")
        item_tag = next((t for t in tags if t.startswith("item::")), None)
        if not item_tag:
            return
        _, section, ci, ii = item_tag.split("::")
        item = self.budget.sections[section][int(ci)].items[int(ii)]
        self._open_editor(item)

    def _open_editor(self, item):
        dlg = tk.Toplevel(self)
        dlg.title("Edit Line Item")
        dlg.transient(self)
        dlg.grab_set()

        rows = [("Account", "account"), ("Description", "description"),
                ("Qty", "qty"), ("Units", "units"), ("Rate", "rate")]
        vars_ = {}
        for r, (label, attr) in enumerate(rows):
            ttk.Label(dlg, text=label).grid(row=r, column=0, sticky="e", padx=8, pady=4)
            v = tk.StringVar(value=str(getattr(item, attr)))
            ttk.Entry(dlg, textvariable=v, width=30).grid(row=r, column=1, padx=8, pady=4)
            vars_[attr] = v

        # Schedule link dropdown
        ttk.Label(dlg, text="Link to schedule").grid(
            row=len(rows), column=0, sticky="e", padx=8, pady=4)
        tag_options = [""] + sorted(self._get_day_map().keys())
        link_var = tk.StringVar(value=item.schedule_tag)
        link_box = ttk.Combobox(dlg, textvariable=link_var, values=tag_options,
                                width=27, state="readonly")
        link_box.grid(row=len(rows), column=1, padx=8, pady=4)

        hint = ("When linked, Qty auto-fills from the schedule's day count "
                "for that tag (use the Sync from Schedule button).")
        ttk.Label(dlg, text=hint, foreground="#666", wraplength=300,
                  justify="left").grid(row=len(rows) + 1, column=0, columnspan=2,
                                       padx=8, pady=(0, 6))

        def save():
            try:
                item.account = vars_["account"].get()
                item.description = vars_["description"].get()
                item.qty = float(vars_["qty"].get())
                item.units = vars_["units"].get()
                item.rate = float(vars_["rate"].get())
                item.schedule_tag = link_var.get().strip()
            except ValueError:
                messagebox.showerror("Invalid", "Qty and Rate must be numbers.", parent=dlg)
                return
            # If newly linked, pull the current day count immediately
            if item.schedule_tag:
                dm = self._get_day_map()
                if item.schedule_tag in dm:
                    item.qty = dm[item.schedule_tag]
            dlg.destroy()
            self._reload_tree()

        ttk.Button(dlg, text="Save", command=save).grid(
            row=len(rows) + 2, column=0, columnspan=2, pady=10)

    def _prompt(self, msg):
        dlg = tk.Toplevel(self)
        dlg.title("Input")
        dlg.transient(self)
        dlg.grab_set()
        ttk.Label(dlg, text=msg).pack(padx=12, pady=8)
        var = tk.StringVar()
        entry = ttk.Entry(dlg, textvariable=var, width=30)
        entry.pack(padx=12)
        entry.focus_set()
        result = {}
        def ok():
            result["value"] = var.get().strip()
            dlg.destroy()
        ttk.Button(dlg, text="OK", command=ok).pack(pady=10)
        self.wait_window(dlg)
        return result.get("value")

    # ---------- Persistence (UI) ----------
    def _set_path(self, path):
        self.current_path = path
        self.path_label.config(text=path if path else "(unsaved)")

    def _new(self):
        if not messagebox.askyesno("New budget",
                                   "Discard the current budget and start fresh?"):
            return
        self.budget = FilmBudget(self.proj_var.get() or "Untitled Project")
        self._set_path(None)
        self.fringe_var.set(str(self.budget.fringe_pct))
        self.cont_var.set(str(self.budget.contingency_pct))
        self._reload_tree()

    def _open(self):
        path = filedialog.askopenfilename(
            filetypes=[("Budget JSON", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            self.budget = FilmBudget.load_json(path)
        except Exception as e:
            messagebox.showerror("Open failed", str(e))
            return
        self._set_path(path)
        self.proj_var.set(self.budget.project_name)
        self.fringe_var.set(str(self.budget.fringe_pct))
        self.cont_var.set(str(self.budget.contingency_pct))
        self._reload_tree()

    def _save(self):
        if not self.current_path:
            return self._save_as()
        self._recalc()
        try:
            self.budget.save_json(self.current_path)
            messagebox.showinfo("Saved", f"Saved to:\n{self.current_path}")
        except Exception as e:
            messagebox.showerror("Save failed", str(e))

    def _save_as(self):
        self._recalc()
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("Budget JSON", "*.json")],
            initialfile=f"{self.budget.project_name.replace(' ', '_')}_budget.json")
        if not path:
            return
        self._set_path(path)
        self._save()

    # ---------- Excel export ----------
    def _export(self):
        if not OPENPYXL_AVAILABLE:
            messagebox.showerror(
                "Missing library",
                "openpyxl is not installed.\n\nRun:  pip3 install openpyxl")
            return
        self._recalc()
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel Workbook", "*.xlsx")],
            initialfile=f"{self.budget.project_name.replace(' ', '_')}_budget.xlsx")
        if not path:
            return
        try:
            self._write_workbook(path)
            messagebox.showinfo("Exported", f"Budget saved to:\n{path}")
        except Exception as e:
            messagebox.showerror("Export failed", str(e))

    def _write_workbook(self, path):
        b = self.budget
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Budget"

        title_font = Font(size=16, bold=True, color="FFFFFF")
        title_fill = PatternFill("solid", fgColor="1F3A5F")
        sec_font = Font(bold=True, color="FFFFFF")
        sec_fill = PatternFill("solid", fgColor="2E5984")
        cat_font = Font(bold=True)
        cat_fill = PatternFill("solid", fgColor="DCE6F2")
        tot_font = Font(bold=True)
        tot_fill = PatternFill("solid", fgColor="FFF3CD")
        money_fmt = '$#,##0.00'
        thin = Side(style="thin", color="CCCCCC")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        center = Alignment(horizontal="center")
        right = Alignment(horizontal="right")

        headers = ["Account", "Description", "Qty", "Units", "Rate", "Linked", "Total"]
        ncols = len(headers)

        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
        c = ws.cell(row=1, column=1, value=f"{b.project_name} — Film Budget")
        c.font = title_font
        c.fill = title_fill
        c.alignment = center
        ws.cell(row=2, column=1,
                value=f"Generated {datetime.now():%Y-%m-%d %H:%M}").font = Font(italic=True)

        row = 4
        for col, h in enumerate(headers, start=1):
            cell = ws.cell(row=row, column=col, value=h)
            cell.font = Font(bold=True)
            cell.border = border
            cell.alignment = center
        row += 1

        for section in b.SECTIONS:
            ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols - 1)
            sc = ws.cell(row=row, column=1, value=section)
            sc.font = sec_font
            sc.fill = sec_fill
            st = ws.cell(row=row, column=ncols, value=b.section_total(section))
            st.font = sec_font
            st.fill = sec_fill
            st.number_format = money_fmt
            row += 1

            for cat in b.sections[section]:
                ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols - 1)
                cc = ws.cell(row=row, column=1, value="   " + cat.name)
                cc.font = cat_font
                cc.fill = cat_fill
                ct = ws.cell(row=row, column=ncols, value=cat.subtotal)
                ct.font = cat_font
                ct.fill = cat_fill
                ct.number_format = money_fmt
                row += 1

                for item in cat.items:
                    link_txt = item.schedule_tag if item.linked else ""
                    vals = [item.account, "      " + item.description, item.qty,
                            item.units, item.rate, link_txt, item.total]
                    for col, v in enumerate(vals, start=1):
                        cell = ws.cell(row=row, column=col, value=v)
                        cell.border = border
                        if col in (5, 7):
                            cell.number_format = money_fmt
                            cell.alignment = right
                        elif col == 3:
                            cell.alignment = right
                    row += 1

        row += 1
        def total_row(label, value, bold=True):
            nonlocal row
            ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols - 1)
            lc = ws.cell(row=row, column=1, value=label)
            lc.font = tot_font if bold else Font()
            lc.fill = tot_fill
            lc.alignment = right
            vc = ws.cell(row=row, column=ncols, value=value)
            vc.font = tot_font if bold else Font()
            vc.fill = tot_fill
            vc.number_format = money_fmt
            row += 1

        total_row("Total Direct Costs", b.direct_total)
        total_row(f"Fringes ({b.fringe_pct}%)", b.fringe_amount, bold=False)
        total_row("Subtotal w/ Fringes", b.subtotal_with_fringes)
        total_row(f"Contingency ({b.contingency_pct}%)", b.contingency_amount, bold=False)
        total_row("GRAND TOTAL", b.grand_total)

        widths = [10, 38, 8, 9, 13, 16, 15]
        for i, w in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = w

        ws.freeze_panes = "A5"
        wb.save(path)


# Standalone test with a fake schedule provider
if __name__ == "__main__":
    def demo_schedule():
        return {"Total": 24, "INT. Warehouse": 6, "EXT. Beach": 3}

    root = tk.Tk()
    root.withdraw()
    BudgetWindow(root, project_name="My Feature Film",
                 schedule_provider=demo_schedule)
    root.mainloop()